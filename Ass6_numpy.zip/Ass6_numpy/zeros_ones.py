import numpy


inp = tuple(map(int,input().strip().split()))
print( numpy.zeros(inp, int) )
print( numpy.ones(inp, int) )
                    