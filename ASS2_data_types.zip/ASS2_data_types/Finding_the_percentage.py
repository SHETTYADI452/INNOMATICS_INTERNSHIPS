if __name__ == '__main__':
    
    #no of Students
    n = int(input())
    
    #iniatializing  dict that stores students scores
    student_marks = {}
    for _ in range(n):
        name, *line = input().split()
        scores = list(map(float, line))
        student_marks[name] = scores
    query_name = input()
    
    marks=0
    for i in student_marks[query_name]:
        marks=marks+i
    average=marks/3
    print("%.2f"%average)