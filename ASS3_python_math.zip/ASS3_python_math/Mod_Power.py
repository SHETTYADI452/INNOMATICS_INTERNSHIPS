# Enter your code here. Read input from STDIN. Print output to STDOUT

a=int(input())
b=int(input())
m=int(input())

print (pow(a,b))
print (pow(a,b,m))
