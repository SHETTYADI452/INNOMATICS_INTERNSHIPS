# Enter your code here. Read input from STDIN. Print output to STDOUT
import re

i=int(input())
for _ in range(i)
    print(re.search(r'^([-+])d.d+$', input()) is not None)
    
