#Declaring variables to store String
my_string = "Hello, World!"

#printing the String
print(my_string)