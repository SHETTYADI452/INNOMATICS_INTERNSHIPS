 n = int(input())

for i in range(n):
    i += 1
    print(i,end=""))